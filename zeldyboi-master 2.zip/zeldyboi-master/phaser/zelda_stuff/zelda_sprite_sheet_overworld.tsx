<?xml version="1.0" encoding="UTF-8"?>
<tileset name="zelda_sprite_sheet_overworld" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="126" columns="18">
 <image source="../Downloads/zelda_sprite_sheet_overworld.png" width="307" height="119"/>
</tileset>
