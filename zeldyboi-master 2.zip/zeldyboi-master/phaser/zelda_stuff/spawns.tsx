<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spawns" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="12" columns="3">
 <image source="spawn_locations.png" width="54" height="72"/>
</tileset>
