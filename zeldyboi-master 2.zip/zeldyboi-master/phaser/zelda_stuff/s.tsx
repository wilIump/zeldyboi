<?xml version="1.0" encoding="UTF-8"?>
<tileset name="s" tilewidth="16" tileheight="16" spacing="14" tilecount="112" columns="14">
 <image source="sprite_sheet_enemy.png" width="435" height="226"/>
</tileset>
